Configuration DownLoadExchange {

    Import-DscResource -ModuleName PSDesiredStateConfiguration, xPSDesiredStateConfiguration

    Node localhost {

    LocalConfigurationManager {
        ConfigurationMode = 'ApplyOnly'
    }
    
    File Destination {
        DestinationPath = 'c:\ISOPath'
        Ensure = 'Present'
        }
    }
    xRemoteFile ExchangeISO {
        DestinationPath = 'c:\ISOPath'
        DependsOn = "[File]Destination"
        Uri = 'http://go.microsoft.com/fwlink/?LinkID=121721&arch=x64'
    }
}